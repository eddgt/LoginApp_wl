@javax.xml.bind.annotation.XmlSchema(namespace = "http://tigobusiness.tigo.com.gt/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ws;
